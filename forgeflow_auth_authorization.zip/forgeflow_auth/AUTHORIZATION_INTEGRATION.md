# ForgeFlow authentication and project role authorization

This adds project-scoped role checks to the auth package from this bundle. It expects the `project_members` table to contain `project_id`, `user_id`, and `role`, with roles `OWNER`, `ADMIN`, and `MEMBER`.

## Middleware order

Register protected handlers by wrapping authorization *inside* authentication: first `authHandler.RequireAuth`, then `authorization.RequireProjectRole`.

```go
roleStore := authorization.NewPostgresProjectRoleStore(db)

protected := func(handler http.Handler, param string, roles ...string) http.Handler {
    roleCheck := authorization.RequireProjectRole(roleStore, param, roles...)(handler)
    return authHandler.RequireAuth(roleCheck)
}

router.Handle("GET /api/v1/projects/{id}", protected(
    http.HandlerFunc(projectHandler.GetProject), "id", "OWNER", "ADMIN", "MEMBER",
))
router.Handle("PUT /api/v1/projects/{id}", protected(
    http.HandlerFunc(projectHandler.UpdateProject), "id", "OWNER", "ADMIN",
))
router.Handle("DELETE /api/v1/projects/{id}", protected(
    http.HandlerFunc(projectHandler.DeleteProject), "id", "OWNER",
))
router.Handle("POST /api/v1/projects/{project_id}/members", protected(
    http.HandlerFunc(projectHandler.AddMember), "project_id", "OWNER", "ADMIN",
))
router.Handle("POST /api/v1/projects/{project_id}/tasks", protected(
    http.HandlerFunc(taskHandler.CreateTask), "project_id", "OWNER", "ADMIN", "MEMBER",
))
```

Add imports:

```go
"github.com/Suryy16/ForgeFlow/internal/auth"
"github.com/Suryy16/ForgeFlow/internal/authorization"
```

## Important route caveats

- Public auth routes (`POST /api/v1/auth/register`, `POST /api/v1/auth/login`) must not be wrapped.
- The route `GET /api/v1/projects` has no project ID in its path. It should query only projects the authenticated user belongs to; a per-project path middleware cannot safely scope this list endpoint.
- Task `GET /api/v1/tasks`, `GET /api/v1/tasks/{id}`, `PUT /api/v1/tasks/{id}`, and `DELETE /api/v1/tasks/{id}` also lack a project ID path parameter. Do not expose them as protected-only and assume that is enough: their repository queries must also enforce project membership / task-project ownership. A follow-up should add task-aware authorization middleware or user-scoped repository methods that resolve `task_id -> project_id`.
- `POST /api/v1/projects` should be authentication-only. The handler must set `owner_id` from `auth.UserIDFromContext(r.Context())`, never from client-provided `owner_id`, and should create the project and OWNER membership in one database transaction.
- Ensure `project_members.role` values are stored consistently as uppercase `OWNER`, `ADMIN`, `MEMBER`.
- If project role is stored on `project_members`, do not put that role in the JWT: memberships and roles can change while a token is still valid.

## Suggested permission policy

- Project read: `OWNER`, `ADMIN`, `MEMBER`
- Project update: `OWNER`, `ADMIN`
- Project delete: `OWNER`
- Add member: `OWNER`, `ADMIN` (application logic should prevent ADMIN from granting OWNER)
- Create task: any project member

This middleware returns JSON errors in the same `{ "error": "..." }` shape. `401` means no valid authentication context, `403` means the user is not a member or lacks the required role, `400` means an invalid project ID, and `500` means permission verification failed.
